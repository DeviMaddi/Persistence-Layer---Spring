package com.example.crud.Controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.crud.entity.Employee;
import com.example.crud.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class Controller {

	@Autowired
	private EmployeeService service;
	
	@PostMapping("/save")
	public Employee saveEmployee(@RequestBody Employee emp) {  // to add a employee
		return service.saveOrUpdateEmployee(emp);
	}
	
	@GetMapping("/getAll")
	public Iterable<Employee>  getAllEmployee() {  // to get list of employee
		return service.getEmployees();
	}
	
	@GetMapping("/{id}")
	public Optional<Employee> getEmpById(@PathVariable Long id){   // to get employee by id
		return service.getEmplById(id);
	}
	
	@GetMapping("/exists/{id}")
	public boolean empExists(@PathVariable Long id) {     // checking employee exists or not
		return service.emplExists(id);
	}
	
	@GetMapping("/count")
	public Long empCount() {
		return service.getEmpCount();
	}
	
	@DeleteMapping("/delete/{id}")
	public void deleteEmpId(@PathVariable Long id) {
		service.delById(id);
	}
	
	@DeleteMapping("/delete")
	public void deleteAll() {
		 service.deleteAllEmp();
	}
}
