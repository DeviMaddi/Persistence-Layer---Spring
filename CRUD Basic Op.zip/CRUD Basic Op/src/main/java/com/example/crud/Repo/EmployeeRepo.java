package com.example.crud.Repo;

import org.springframework.data.repository.CrudRepository;

import com.example.crud.entity.Employee;

public interface EmployeeRepo extends CrudRepository<Employee, Long> {

}
