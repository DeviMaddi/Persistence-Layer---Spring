package com.example.crud.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.Service;

import com.example.crud.Repo.EmployeeRepo;
import com.example.crud.entity.Employee;

@Service
public class EmployeeService {
  
	@Autowired
	private EmployeeRepo repo;
	
	public Employee saveOrUpdateEmployee(Employee employee) {
		return repo.save(employee);
	}
	
	

	public Iterable<Employee> getEmployees() {
	
		return repo.findAll();
	}



	public Optional<Employee> getEmplById(Long id) {
		
		return repo.findById(id);
	}



	public boolean emplExists(Long id) {
		// TODO Auto-generated method stub
		return repo.existsById(id);         // to check
	}



	public Long getEmpCount() {
		
		return repo.count();    // to count all employees
	}



	public void delById(Long id) {
		
		 repo.deleteById(id);
	}



	public void deleteAllEmp() {
	     repo.deleteAll();
		
	}
	
	
}
